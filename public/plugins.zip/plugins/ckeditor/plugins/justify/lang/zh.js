/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'justify', 'zh', {
	block: '左右對齊',
	center: '置中',
	left: '靠左對齊',
	right: '靠右對齊'
} );
